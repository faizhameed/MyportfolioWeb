var button = document.querySelector(".btn-primary");

button.onclick = function() {
  console.log("hi");
  alert("Your Message has been sent");
};
